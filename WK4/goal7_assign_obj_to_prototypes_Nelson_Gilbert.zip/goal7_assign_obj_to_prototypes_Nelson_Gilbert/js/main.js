/** Gilbert Nelson
 Analyze objects.person project
 10/23/2015 */

/* create array called names and have 5 names in it
        array 0 = fred
        array 1 = ben
        array 2 = wilma
        array 3 = greg
        array 4 = derek
 */
/* create object person using for loop
    for()
        var Person = newPerson()
            create persons reference array name people
                array 0 = age
                array 1 = jobs
                array 2 = action
   use Math.random() to make sure names are never the same
 */
/* function (populateHTML)
       var person = newPerson(names[someName],someRow) so no repeat of names
       this.name = fred
       this.jobs = judge
       this.action = eat
       this name = newPerson[Math.floor(Math.random()*names.length)]
    setInterval(runUpdate, 1000/30) to change salary at secs interval
 */
/* Create for loop for runUpdate
        runUpdate(){people.forEach(populateHTML(newPerson){
        element.update()
        })
 */