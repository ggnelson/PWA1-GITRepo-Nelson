/**Gilbert Nelson
 Analyze objects.person project
 10/23/2015
 */
/* create global window object to connect to main.js
        window.Person=Person
 */
/*create two variables objects to reference to Object Person
    var Person.jobs = ["judge","detective","defense","attorney"]
    var Person.actions = ["eating","sleeping","driving"]

    create constructor
 var person = newPerson(names[someName],someRow) so no repeat of names
 this.name = fred
 this.jobs = judge
 this.action = eat
 this.row = 3
 this name = newPerson[Math.floor(Math.random()*names.length)]

 Create for loop for runUpdate
 runUpdate(){people.forEach(populateHTML(newPerson){
 element.update()
 })
 */